Other software included in this distribution is owned and
licensed separately, see the included license files for details.